using Xunit;
using System.IO;
using Moq;
using Microsoft.Extensions.Logging;
using Function.Domain.Helpers;
using Function.Domain.Models;
using Newtonsoft.Json;

namespace UnitTests.Function.Domain.Helpers
{
    public class SparkProcessParserTests
    {
        private ISparkProcessParser _sparkProcessParser;
        const string SPARK_APP_QN = "notebook://folder/folder/filename";
        const string SPARK_APP_GUID = "-1";
        private ParserSettings _config = UnitTestData.SharedTestData.Settings;

        public SparkProcessParserTests()
        {
            var mockLogger = new Mock<ILogger>();
            _sparkProcessParser = new SparkProcessParser(_config, SPARK_APP_QN, SPARK_APP_GUID, UnitTestData.SparkProcessParserTestData.GetEvent(), mockLogger.Object);
        }

        [Fact]          
        public void Function_Tested_Inputs_ExpectedResult()
        {
           var rslt = _sparkProcessParser.GetSparkProcess();

           string procOut = JsonConvert.SerializeObject(rslt);

            //Pass the filepath and filename to the StreamWriter Constructor
            StreamWriter sw = new StreamWriter(".\\LogSparkProcessParser.txt");
            sw.Write(procOut);
            sw.Close();

            // Manually verifying output for now, will add success criteria later
            //Xunit.Assert.Equal(expectedResult, rslt);
        }
    }
}