using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Function.Domain.Helpers;
using Function.Domain.Models;
using Function.Domain.Models.OL;
using System.Collections.Generic;

namespace UnitTests.Function.Domain.Helpers
{
    public class QnParserTests
    {
        private ParserSettings _config = UnitTestData.SharedTestData.Settings;
        private List<MountPoint> _mounts_info = UnitTestData.QnParserTestData.MountPoints;

        private IQnParser _qnparser;

        public QnParserTests()
        {
            var _mockLogger = new Mock<ILogger>();
            _qnparser = new QnParser(_mounts_info,_config, _mockLogger.Object);
        }


        // Tests Qualified Name parsing for each scenario
        [Theory]
        // WASBS Blob - only supported in Azure Storage, not ADLS Gen2
        [InlineData("wasbs://rawdata@splineexamplessa.blob.core.windows.net", 
                    "/retail", 
                    "https://splineexamplessa.blob.core.windows.net/rawdata/retail")]
        // WASB
        [InlineData("wasb://rawdata@splineexamplessa.blob.core.windows.net", 
                    "/retail", 
                    "https://splineexamplessa.blob.core.windows.net/rawdata/retail")]
        // ABFSS
        [InlineData("abfss://rawdata@splineexamplessa.dfs.core.windows.net", 
                    "/retail", 
                    "https://splineexamplessa.dfs.core.windows.net/rawdata/retail")]
        // ABFS
        [InlineData("abfs://rawdata@splineexamplessa.dfs.core.windows.net", 
                    "/retail", 
                    "https://splineexamplessa.dfs.core.windows.net/rawdata/retail")]
        // ABFSS - Blob
        [InlineData("abfss://rawdata@splineexamplessa.blob.core.windows.net", 
                    "/retail", 
                    "https://splineexamplessa.dfs.core.windows.net/rawdata/retail")]
        // Cosmos
        [InlineData("azurecosmos://purview-to-adb-cdb.documents.azure.com/dbs/NewWriteScalaDB", 
                    "/colls/NewWriteScalaCon", 
                    "https://purview-to-adb-cdb.documents.azure.com/dbs/NewWriteScalaDB/colls/NewWriteScalaCon")]
        // Azure SQL
        [InlineData("sqlserver://purview-to-adb-sql.database.windows.net:1433;database=purview-to-adb-sqldb;encrypt=true;", 
                    "borrower_with_pid", 
                    "mssql://purview-to-adb-sql.database.windows.net/purview-to-adb-sqldb/dbo/borrower_with_pid")]
        // Synapse
        [InlineData("sqlserver://purviewadbsynapsews.sql.azuresynapse.net:1433;database=SQLPool1;", 
                    "exampleinputA", 
                    "mssql://purviewadbsynapsews.sql.azuresynapse.net/SQLPool1/dbo/exampleinputA")]
        // DBFS mount
        [InlineData("dbfs", 
                    "/mnt/rawdata/retail", 
                    "https://splineexamplessa.dfs.core.windows.net/rawdata/retail")]  
        // DBFS mount trailing slash in def
        [InlineData("dbfs", 
                    "/mnt/purview2", 
                    "https://splineexamplessa.dfs.core.windows.net/purview2")]  
        // DBFS
        [InlineData("dbfs", 
                    "/temp/rawdata/retail", 
                    "unknown-dbfs:///temp/rawdata/retail")]
        // Azure SQL Non DBO Schema - <need verification of Purview string>
        [InlineData("sqlserver://purview-to-adb-sql.database.windows.net;databaseName=purview-to-adb-sqldb;", 
                    "[mytest].[tablename.will.mark]", 
                    "mssql://purview-to-adb-sql.database.windows.net/purview-to-adb-sqldb/mytest/tablename.will.mark")]
        // Synapse Non DBO Schema
        [InlineData("sqlserver://purviewadbsynapsews.sql.azuresynapse.net:1433;database=SQLPool1;", 
                    "sales.region", 
                    "mssql://purviewadbsynapsews.sql.azuresynapse.net/SQLPool1/sales/region")]         
        public void GetIdentifiers_OlSource_ReturnsPurviewIdentifier(string nameSpace, string name, string expectedResult)
        {
            var rslt = _qnparser.GetIdentifiers(nameSpace, name);

            Xunit.Assert.Equal(expectedResult, rslt.QualifiedName);
        }
    }
}