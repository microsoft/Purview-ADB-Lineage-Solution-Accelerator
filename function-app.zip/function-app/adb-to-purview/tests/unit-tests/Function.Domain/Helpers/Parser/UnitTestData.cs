using Function.Domain.Models;
using Function.Domain.Models.OL;
using Function.Domain.Models.Purview;
using Newtonsoft.Json;
using System.Collections;
using System.Collections.Generic;

namespace UnitTests.Function.Domain.Helpers
{
    public class FilterOlEventTestData : IEnumerable<object[]>
    {
        public IEnumerator<object[]> GetEnumerator()
        {
            // StartFullMessage
            yield return new object[] {"StartFullMessage: 2022-01-12T00:05:53.282 [Information] OpenLineageIn:{\"eventType\":\"START\",\"eventTime\":\"2022-01-25T17:52:53.363Z\",\"inputs\":[{\"namespace\":\"dbfs\",\"name\":\"/mnt/raw/DimProduct.parquet\"}],\"outputs\":[{\"namespace\":\"dbfs\",\"name\":\"/mnt/destination/DimProduct.parquet\"}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , true};
            // CompleteNoOutputsInputsFullMessage
            yield return new object[] {"CompleteNoOutputsInputsFullMessage: 2022-01-12T00:05:56.318 [Information] OpenLineageIn:{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-25T17:52:53.363Z\",\"inputs\":[],\"outputs\":[{\"namespace\":\"dbfs\",\"name\":\"/mnt/raw/DimProduct.parquet\"}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , false};
            // CompleteOutputsAndInputsFullMessage
            yield return new object[] {"CompleteOutputsAndInputsFullMessage: 2022-01-12T00:19:41.550 [Information] OpenLineageIn:{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-25T17:52:53.363Z\",\"inputs\":[{\"namespace\":\"dbfs\",\"name\":\"/mnt/raw/DimProduct.parquet\"}],\"outputs\":[{\"namespace\":\"dbfs\",\"name\":\"/mnt/destination/DimProduct.parquet\"}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , true};
            // CompleteOutputsAndInputsSame
            yield return new object[] {"{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-25T17:52:53.363Z\",\"inputs\":[{\"namespace\":\"dbfs\",\"name\":\"/mnt/raw/DimProduct.parquet\"}],\"outputs\":[{\"namespace\":\"dbfs\",\"name\":\"/mnt/raw/DimProduct.parquet\"}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , false};
            // Garbage
            /* cspell: disable-next-line */
            yield return new object[] {"jfinaalksk)(^%(%6#%^&[];;asoidhntggpa;phgaqpirgp"
            , false};
            // SameInOut
            yield return new object[] {"{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-11T09:52:25.344Z\",\"run\":{},\"job\":{},\"inputs\":[{\"namespace\":\"wasbs://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"foo://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"outputs\":[{\"namespace\":\"wasbs://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"foo://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , false};
            // SameInOutDiffOrder
            yield return new object[] {"{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-11T09:52:25.344Z\",\"run\":{},\"job\":{},\"inputs\":[{\"namespace\":\"wasbs://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"foo://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"outputs\":[{\"namespace\":\"foo://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"wasbs://outputdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{},\"outputFacets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , false};
            // DiffInOut
            yield return new object[] {"{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-11T09:52:25.344Z\",\"run\":{},\"job\":{},\"inputs\":[{\"namespace\":\"wasbs://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"foo://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"outputs\":[{\"namespace\":\"wasbs://outputdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail/wasbdemo_updated\",\"facets\":{},\"outputFacets\":{}},{\"namespace\":\"wasbs://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , true};
            // SameInOutCasingOrderSlash
            yield return new object[] {"{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-11T09:52:25.344Z\",\"run\":{},\"job\":{},\"inputs\":[{\"namespace\":\"wasbs://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"foo://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"outputs\":[{\"namespace\":\"foo://rawdata@SplineExamplessa.blob.core.windows.net/\",\"name\":\"/retail\",\"facets\":{}},{\"namespace\":\"wasbs://outputdata@splineexamplessa.blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{},\"outputFacets\":{}},{\"namespace\":\"bar://rawdata@splineexamplessa.Blob.core.windows.net\",\"name\":\"/retail\",\"facets\":{}}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.5.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}"
            , false};
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    public static class UnitTestData
    {

        public struct OlToPurviewParsingServiceTestData
        {
            public const string CompleteOlMessage = "{\"eventType\":\"COMPLETE\",\"eventTime\":\"2022-01-25T19:36:00.668Z\",\"run\":{\"runId\":\"225e05d7-5c5a-434c-a544-ffbda7dfa44b\",\"facets\":{\"environment-properties\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunFacet\",\"environment-properties\":{\"spark.databricks.clusterUsageTags.clusterName\":\"CMI_Purview_POC01\",\"spark.databricks.clusterUsageTags.azureSubscriptionId\":\"f48a1ead-b2e2-48b7-9575-b2cf93652fa6\",\"spark.databricks.notebook.path\":\"/Shared/Scenario01DimOrg/S01DimOrg_raw2int\",\"mountPoints\":[{\"mountPoint\":\"/databricks-datasets\",\"source\":\"s3a://databricks-datasets-oregon/\"},{\"mountPoint\":\"/databricks/mlflow-tracking\",\"source\":\"unsupported-access-mechanism-for-path--use-mlflow-client:/\"},{\"mountPoint\":\"/databricks-results\",\"source\":\"wasbs://ephemeral@dbstorage3237izou4adxk.blob.core.windows.net/3464153745686717\"},{\"mountPoint\":\"/mnt/raw\",\"source\":\"abfss://raw@aaiarchdesignpurviewadls.dfs.core.windows.net/\"},{\"mountPoint\":\"/databricks/mlflow-registry\",\"source\":\"unsupported-access-mechanism-for-path--use-mlflow-client:/\"},{\"mountPoint\":\"/mnt/primary\",\"source\":\"abfss://primary@aaiarchdesignpurviewadls.dfs.core.windows.net/\"},{\"mountPoint\":\"/mnt/integration\",\"source\":\"abfss://integration@aaiarchdesignpurviewadls.dfs.core.windows.net/\"},{\"mountPoint\":\"/\",\"source\":\"wasbs://root@dbstorage3237izou4adxk.blob.core.windows.net/3464153745686717\"}],\"spark.databricks.clusterUsageTags.clusterOwnerOrgId\":\"3464153745686717\",\"user\":\"marktayl@cmiaaval.cummins.com\",\"userId\":\"5533428870378942\",\"orgId\":\"3464153745686717\"}},\"spark_version\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunFacet\",\"spark-version\":\"3.1.2\",\"openlineage-spark-version\":\"0.6.0-SNAPSHOT\"},\"spark.logicalPlan\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunFacet\",\"plan\":[{\"class\":\"org.apache.spark.sql.catalyst.plans.logical.OverwriteByExpression\",\"num-children\":1,\"table\":[{\"class\":\"org.apache.spark.sql.execution.datasources.v2.DataSourceV2Relation\",\"num-children\":0,\"table\":null,\"output\":[[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"OrganizationKey\",\"dataType\":\"integer\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":2018,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"ParentOrganizationKey\",\"dataType\":\"integer\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":2019,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"PercentageOfOwnership\",\"dataType\":\"double\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":2020,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"OrganizationName\",\"dataType\":\"string\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":2021,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"CurrencyKey\",\"dataType\":\"integer\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":2022,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}]],\"catalog\":null,\"identifier\":null,\"options\":null}],\"deleteExpr\":[{\"class\":\"org.apache.spark.sql.catalyst.expressions.Literal\",\"num-children\":0,\"value\":\"true\",\"dataType\":\"boolean\"}],\"query\":0,\"writeOptions\":null,\"isByName\":false,\"requireImplicitCasting\":true},{\"class\":\"org.apache.spark.sql.execution.datasources.LogicalRelation\",\"num-children\":0,\"relation\":null,\"output\":[[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"OrganizationKey\",\"dataType\":\"integer\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":6,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"ParentOrganizationKey\",\"dataType\":\"integer\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":7,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"PercentageOfOwnership\",\"dataType\":\"double\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":8,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"OrganizationName\",\"dataType\":\"string\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":9,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}],[{\"class\":\"org.apache.spark.sql.catalyst.expressions.AttributeReference\",\"num-children\":0,\"name\":\"CurrencyKey\",\"dataType\":\"integer\",\"nullable\":true,\"metadata\":{},\"exprId\":{\"product-class\":\"org.apache.spark.sql.catalyst.expressions.ExprId\",\"id\":10,\"jvmId\":\"45fa987d-eacc-4f30-af81-87eac6172e23\"},\"qualifier\":[]}]],\"isStreaming\":false}]}}},\"job\":{\"namespace\":\"adbpurviewol1\",\"name\":\"databricks_shell.overwrite_by_expression_exec_v1\",\"facets\":{}},\"inputs\":[{\"namespace\":\"abfss://raw@aaiarchdesignpurviewadls.dfs.core.windows.net\",\"name\":\"/DimOrganization.parquet\",\"facets\":{\"dataSource\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/facets/1-0-0/DatasourceDatasetFacet.json#/$defs/DatasourceDatasetFacet\",\"name\":\"abfss://raw@aaiarchdesignpurviewadls.dfs.core.windows.net\",\"uri\":\"abfss://raw@aaiarchdesignpurviewadls.dfs.core.windows.net\"},\"schema\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/facets/1-0-0/SchemaDatasetFacet.json#/$defs/SchemaDatasetFacet\",\"fields\":[{\"name\":\"OrganizationKey\",\"type\":\"integer\"},{\"name\":\"ParentOrganizationKey\",\"type\":\"integer\"},{\"name\":\"PercentageOfOwnership\",\"type\":\"double\"},{\"name\":\"OrganizationName\",\"type\":\"string\"},{\"name\":\"CurrencyKey\",\"type\":\"integer\"}]}},\"inputFacets\":{}}],\"outputs\":[{\"namespace\":\"abfss://integration@aaiarchdesignpurviewadls.dfs.core.windows.net\",\"name\":\"DimOrganization.delta\",\"facets\":{\"dataSource\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/facets/1-0-0/DatasourceDatasetFacet.json#/$defs/DatasourceDatasetFacet\",\"name\":\"abfss://integration@aaiarchdesignpurviewadls.dfs.core.windows.net\",\"uri\":\"abfss://integration@aaiarchdesignpurviewadls.dfs.core.windows.net\"},\"schema\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/facets/1-0-0/SchemaDatasetFacet.json#/$defs/SchemaDatasetFacet\",\"fields\":[{\"name\":\"OrganizationKey\",\"type\":\"integer\"},{\"name\":\"ParentOrganizationKey\",\"type\":\"integer\"},{\"name\":\"PercentageOfOwnership\",\"type\":\"double\"},{\"name\":\"OrganizationName\",\"type\":\"string\"},{\"name\":\"CurrencyKey\",\"type\":\"integer\"}]},\"tableProvider\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/DatasetFacet\",\"provider\":\"delta\",\"format\":\"parquet\"},\"tableStateChange\":{\"_producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"_schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/DatasetFacet\",\"stateChange\":\"overwrite\"}},\"outputFacets\":{}}],\"producer\":\"https://github.com/OpenLineage/OpenLineage/tree/0.6.0-SNAPSHOT/integration/spark\",\"schemaURL\":\"https://openlineage.io/spec/1-0-2/OpenLineage.json#/$defs/RunEvent\"}";
            public static string SettingsString = "{\"OlToPurviewMappings\": [{\"UrlSuffix\":\"\",\"OlPrefix\":\"wasbs\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_datalake_gen2_path\"},{\"UrlSuffix\":\"\",\"OlPrefix\":\"adfss\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_datalake_gen2_path\"},{\"UrlSuffix\":\"\",\"OlPrefix\":\"azurecosmos\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_cosmosdb_sqlapi_collection\"},{\"UrlSuffix\":\"database.windows.net\",\"OlPrefix\":\"sqlserver\",\"PurviewPrefix\":\"mssql\",\"PurviewDatatype\":\"azure_sql_table\"},{\"UrlSuffix\":\"sql.azuresynapse.net\",\"OlPrefix\":\"sqlserver\",\"PurviewPrefix\":\"mssql\",\"PurviewDatatype\":\"azure_synapse_dedicated_sql_table\"},{\"UrlSuffix\":\"\",\"OlPrefix\":\"dbfs\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_datalake_gen2_path\"}]}";
        }
        public struct QnParserTestData
        {
            public static List<MountPoint> MountPoints = new List<MountPoint>()
            {
                new MountPoint(){MountPointName="/databricks/mlflow-registry",Source="databricks/mlflow-registry"},
                new MountPoint(){MountPointName="/databricks-datasets",Source="databricks-datasets"},
                new MountPoint(){MountPointName="/mnt/rawdata",Source="abfss://rawdata@splineexamplessa.dfs.core.windows.net/"},
                new MountPoint(){MountPointName="/databricks/mlflow-tracking",Source="databricks/mlflow-tracking"},
                new MountPoint(){MountPointName="/mnt/delta",Source="abfss://deltalake@splineexamplessa.dfs.core.windows.net/"},
                new MountPoint(){MountPointName="/mnt/outputdata",Source="abfss://outputdata@splineexamplessa.dfs.core.windows.net/"},
                new MountPoint(){MountPointName="/databricks-results",Source="databricks-results"},
                new MountPoint(){MountPointName="/databricks-results",Source="databricks-results"},
                new MountPoint(){MountPointName="/mnt/purview2/",Source="abfss://purview2@splineexamplessa.dfs.core.windows.net/"}
            };
        }

        
       public struct SparkAppParserTestData
       {
            public static EnvironmentProps EnvPropsIn = new EnvironmentProps()
            {
                SparkDatabricksNotebookPath = "/Shared/ABFSS-WASBS/spark-function-tests"
            };

            public static SparkApplication SparkAppOut = new SparkApplication()
            {
                TypeName = "spark_application",
                Attributes = new AppAttributes()
                {
                    Name = "spark-function-tests",
                    AppType = "notebook",
                    QualifiedName = "notebook://Shared/ABFSS-WASBS/spark-function-tests".ToLower()
                },
                Guid = "-1"
            };
       }


        public struct SparkProcessParserTestData
        {
            // Using the null exculsion operator here as json lib should ignore nulls
            public static Event GetEvent()
            {
                var trimString = TrimPrefix(OlToPurviewParsingServiceTestData.CompleteOlMessage);
                Event dEvent = JsonConvert.DeserializeObject<Event>(trimString)!;
                return dEvent;
            }

            private static string TrimPrefix(string strEvent)
            {
                return strEvent.Substring(strEvent.IndexOf('{')).Trim();
            }
        }

        public struct SharedTestData
        {              
            public static ParserSettings Settings = new ParserSettings(){OlToPurviewMappings = new List<OlToPurviewMapping>()
            {
                new OlToPurviewMapping{UrlSuffix="",OlPrefix="wasbs",PurviewPrefix="https",PurviewDatatype="azure_datalake_gen2_path"},
                new OlToPurviewMapping{UrlSuffix="",OlPrefix="abfss",PurviewPrefix="https",PurviewDatatype="azure_datalake_gen2_path"},
                new OlToPurviewMapping{UrlSuffix="",OlPrefix="wasb",PurviewPrefix="https",PurviewDatatype="azure_datalake_gen2_path"},
                new OlToPurviewMapping{UrlSuffix="",OlPrefix="abfs",PurviewPrefix="https",PurviewDatatype="azure_datalake_gen2_path"},
                new OlToPurviewMapping{UrlSuffix="",OlPrefix="azurecosmos",PurviewPrefix="https",PurviewDatatype="azure_cosmosdb_sqlapi_collection"},
                new OlToPurviewMapping{UrlSuffix="database.windows.net",OlPrefix="sqlserver",PurviewPrefix="mssql",PurviewDatatype="azure_sql_table"},
                new OlToPurviewMapping{UrlSuffix="sql.azuresynapse.net",OlPrefix="sqlserver",PurviewPrefix="mssql",PurviewDatatype="azure_synapse_dedicated_sql_table"}
            }};
            public static string SettingsString = "{\"OlToPurviewMappings\": [{\"UrlSuffix\":\"\",\"OlPrefix\":\"wasbs\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_blob_path\"},{\"UrlSuffix\":\"\",\"OlPrefix\":\"wasb\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_blob_path\"},{\"UrlSuffix\":\"\",\"OlPrefix\":\"abfss\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_datalake_gen2_path\"},{\"UrlSuffix\":\"\",\"OlPrefix\":\"abfs\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_datalake_gen2_path\"},{\"UrlSuffix\":\"\",\"OlPrefix\":\"azurecosmos\",\"PurviewPrefix\":\"https\",\"PurviewDatatype\":\"azure_cosmosdb_sqlapi_collection\"},{\"UrlSuffix\":\"database.windows.net\",\"OlPrefix\":\"sqlserver\",\"PurviewPrefix\":\"mssql\",\"PurviewDatatype\":\"azure_sql_table\"},{\"UrlSuffix\":\"sql.azuresynapse.net\",\"OlPrefix\":\"sqlserver\",\"PurviewPrefix\":\"mssql\",\"PurviewDatatype\":\"azure_synapse_dedicated_sql_table\"}]}";
        }
    }
}