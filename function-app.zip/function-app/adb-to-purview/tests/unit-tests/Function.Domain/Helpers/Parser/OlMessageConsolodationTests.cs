using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Function.Domain.Helpers;

namespace UnitTests.Function.Domain.Helpers
{
    public class OlMessageConsolodationTests{

        private Mock<ILogger> _mockLogger;

        public OlMessageConsolodationTests()
        {
            _mockLogger = new Mock<ILogger>();
        }

        [Theory]
        [ClassData(typeof(FilterOlEventTestData))]
        public void ConsolodateEvents_bool_FilterGoodEvents(string msgEvent, bool expectedResult)
        {
            var filterOlEvent = new FilterOlEvent(_mockLogger.Object, msgEvent);
            var rslt = filterOlEvent.Filter();

            Xunit.Assert.Equal(expectedResult, rslt);
        }
    }
}