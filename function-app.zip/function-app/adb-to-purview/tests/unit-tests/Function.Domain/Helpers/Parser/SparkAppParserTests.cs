using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using Function.Domain.Helpers;

namespace UnitTests.Function.Domain.Helpers
{
    public class SparkAppParserTests
    {

        private ISparkAppParser _sparkappprocessor;

        public SparkAppParserTests()
        {
            var _mockLogger = new Mock<ILogger>();
            _sparkappprocessor = new SparkAppParser(_mockLogger.Object);
        }


        // Tests Qualified Name parsing for each scenario
        [Fact]                  
        public void GetQualifiedName_OlSource_ReturnsQualifiedName()
        {
            var rslt = _sparkappprocessor.GetSparkApplication(UnitTestData.SparkAppParserTestData.EnvPropsIn);

            Xunit.Assert.Equal(UnitTestData.SparkAppParserTestData.SparkAppOut.Attributes.Name, rslt.Attributes.Name);
            Xunit.Assert.Equal(UnitTestData.SparkAppParserTestData.SparkAppOut.Attributes.QualifiedName, rslt.Attributes.QualifiedName);
            Xunit.Assert.Equal(UnitTestData.SparkAppParserTestData.SparkAppOut.Attributes.AppType, rslt.Attributes.AppType);
        }
    }
}