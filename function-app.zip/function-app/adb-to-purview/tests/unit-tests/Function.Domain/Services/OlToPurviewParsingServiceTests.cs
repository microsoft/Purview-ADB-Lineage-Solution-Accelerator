using Xunit;
using System.IO;
using System.Threading.Tasks;
using Moq;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Function.Domain.Services;
using Function.Domain.Models;
using Newtonsoft.Json;

namespace UnitTests.Function.Domain.Services
{
    public class OlToPurviewParsingServiceTests
    {
        private IOlToPurviewParsingService _olToPurviewParsingService;
        const string SPARK_APP_QN = "notebook://folder/folder/filename";
        const string SPARK_APP_GUID = "-1";
        private ParserSettings _config = UnitTestData.SharedTestData.Settings;

        public OlToPurviewParsingServiceTests()
        {
            var mockLogger = new Mock<ILogger<OlToPurviewParsingService>>();

            var mydir = Directory.GetCurrentDirectory();

            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory() + "../../../../Function.Domain/Services/")
                .AddJsonFile("TestConfig.json")
                .Build();

            _olToPurviewParsingService = new OlToPurviewParsingService(mockLogger.Object, configuration);
        }

        // Test start event to store environmental facet info
        [Fact]
        public async Task GetPurviewFromOlEvent_OL_start_event_OL_facet_stored()
        {
           var rslt = await _olToPurviewParsingService.GetPurviewFromOlEvent(UnitTestData.OlToPurviewParsingServiceTestData.StartOlWithEnvironment);

            // Manually verifying output for now, will add success criteria later
            //Xunit.Assert.Equal(expectedResult, rslt);
        }

        // Test complete event with no environmental facet info
        [Fact]
        public async Task  GetPurviewFromOlEvent_OL_complete_event_Purview_Entities()
        {
           var rslt = await _olToPurviewParsingService.GetPurviewFromOlEvent(UnitTestData.OlToPurviewParsingServiceTestData.CompleteOlNoEnvironment);

            // Manually verifying output for now, will add success criteria later
            //Xunit.Assert.Equal(expectedResult, rslt);
        }

        // Test general entities
        [Fact] 
        public async Task  GetPurviewFromOlEvent_OL_event_Purview_Entities()
        {
           var rslt = await _olToPurviewParsingService.GetPurviewFromOlEvent(UnitTestData.OlToPurviewParsingServiceTestData.CompleteOlMessage);

            // Manually verifying output for now, will add success criteria later
            //Xunit.Assert.Equal(expectedResult, rslt);
        }
    }
}