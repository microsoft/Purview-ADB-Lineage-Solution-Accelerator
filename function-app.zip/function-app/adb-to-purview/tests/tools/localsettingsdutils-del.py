# copy file to localsettingsdutils.py and fill in the below values

PURVIEW_NAME = "<insert_purview_account_name>"
TENANT_ID = "<insert_tennant_id>"
CLIENT_ID = "<insert_client_id>"
CLIENT_SECRET = "<insert_secret>" 