using Newtonsoft.Json;
namespace Function.Domain.Models.Purview
{
    public class Application
    {
        [JsonProperty("qualifiedName")]
        public string QualifiedName = ""; 
        [JsonProperty("guid")]
        public string Guid = "-1";
    }
}