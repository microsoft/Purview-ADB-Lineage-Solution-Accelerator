using Newtonsoft.Json;
namespace Function.Domain.Models.Purview
{
    public class OlToPurviewMapping
    {
            public string UrlSuffix = ""; 
            public string OlPrefix = ""; 
            public string PurviewPrefix = ""; 
            public string PurviewDatatype = ""; 
    }

}