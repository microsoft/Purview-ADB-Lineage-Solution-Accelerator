using Newtonsoft.Json;
namespace Function.Domain.Models.Purview
{
    public class AppAttributes
    {
        [JsonProperty("name")]
        public string Name = "";
        [JsonProperty("appType")]
        public string AppType = "";
        [JsonProperty("qualifiedName")]
        public string QualifiedName = "";
    }
}