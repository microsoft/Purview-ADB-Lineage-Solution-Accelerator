using Newtonsoft.Json;
namespace Function.Domain.Models.Purview
{
    public class RelationshipAttributes
    {
        [JsonProperty("application")]
        public Application Application = new Application();
    }

}