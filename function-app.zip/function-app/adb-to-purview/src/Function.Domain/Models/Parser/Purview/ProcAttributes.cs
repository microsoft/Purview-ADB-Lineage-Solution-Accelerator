using System.Collections.Generic;
using Newtonsoft.Json;

namespace Function.Domain.Models.Purview
{
       public class ProcAttributes
    {
         [JsonProperty("name")]
        public string Name = "";
        [JsonProperty("qualifiedName")]
        public string QualifiedName = ""; 
        [JsonProperty("columnMapping")]
        public string ColumnMapping = ""; 
         [JsonProperty("executionId")]
        public string ExecutionId = "0"; 
         [JsonProperty("currUser")]
        public string CurrUser = ""; 
         [JsonProperty("sparkPlanDescription")]
        public string SparkPlanDescription = ""; 
         [JsonProperty("inputs")]
        public List<InputOutput>? Inputs = new List<InputOutput>();
         [JsonProperty("outputs")]
        public List<InputOutput>? Outputs = new List<InputOutput>();
    }

}