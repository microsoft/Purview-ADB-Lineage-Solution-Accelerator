using Newtonsoft.Json;
namespace Function.Domain.Models.Purview
{
    public class SparkProcess
    {
        [JsonProperty("typeName")]
        public string TypeName = "spark_process";
        [JsonProperty("guid")]
        public string Guid = "-2";
        [JsonProperty("attributes")]
        public ProcAttributes Attributes = new ProcAttributes();
        [JsonProperty("relationshipAttributes")]
        public RelationshipAttributes RelationshipAttributes = new RelationshipAttributes();
    }
}