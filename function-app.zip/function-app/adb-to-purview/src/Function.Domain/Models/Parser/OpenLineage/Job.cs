namespace Function.Domain.Models.OL
{
    public class Job
    {
        public string Namespace = "";
        public string Name = "";
    }
}