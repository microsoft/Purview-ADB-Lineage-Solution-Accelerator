namespace Function.Domain.Models.OL
{
    public class Run
    {
        public string RunId = "";
        public Facets Facets = new Facets();
    }
}

