using System.Collections.Generic;
using Function.Domain.Models.Purview;

namespace Function.Domain.Models
{
    public class ParserSettings
    {
        public List<OlToPurviewMapping> OlToPurviewMappings = new List<OlToPurviewMapping>();
    }

}