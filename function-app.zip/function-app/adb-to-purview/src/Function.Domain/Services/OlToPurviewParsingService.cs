using System;
using System.Threading.Tasks;
using Function.Domain.Models.OL;
using Function.Domain.Models;
using Newtonsoft.Json;
using Function.Domain.Helpers;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

namespace Function.Domain.Services
{
    public class OlToPurviewParsingService : IOlToPurviewParsingService
    {
        private ILogger<OlToPurviewParsingService> _log;
        const string SETTINGS = "OlToPurviewMappings";
        const string PREFIX = "{\"entities\": [";
        const string SUFFIX = "]}";
        private ParserSettings _parserConfig;
        private IConfiguration _config;

        public OlToPurviewParsingService(ILogger<OlToPurviewParsingService> log, IConfiguration config)
        {
            _log = log;
            var map = config[SETTINGS];
            _config = config;
            try{
            _parserConfig = JsonConvert.DeserializeObject<ParserSettings>(map) ?? throw new System.Exception("critical config not found");
            } catch {
                _log.LogError("OlToPurviewParsingService: Error retrieving ParserSettings.  Please make sure these are configured on your function.");
                throw;
            }
        }

        public async Task<string> GetPurviewFromOlEvent(string olEventStr)
        {
            Event olEvent = GetEntityFromString(olEventStr);
            // See if notebook needs to be filled in for Spark 2 job
            IAdbClientHelper adbHelper = new AdbClientHelper(_config, _log);
            string? nbpath = olEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties.SparkDatabricksNotebookPath;
            if (nbpath is null || nbpath == "")
            {   
                // For the third parameter (adb url workspace name) we require this be the first part of the OL cluster namespace followed by
                // '#' then the cluster ID
                var namespaceSplit = olEvent.Job.Namespace.Split('#');
                if (namespaceSplit.Length != 2)
                {
                    _log.LogError("OlToPurviewParsingService-GetPurviewFromOlEvent", "Error: Adb Workspace URL name not found - Spark 2 support not enabled");
                    return "";
                }
                try
                {
                    var notebookName = await adbHelper.GetSingleAdbJobAsync("correlationId", 
                                                    long.Parse(olEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties.SparkDatabricksJobRunId),
                                                    olEvent.Job.Namespace.Split('#')[0]);

                    olEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties.SparkDatabricksNotebookPath = notebookName;
                }
                catch(Exception ex)
                {
                    _log.LogError("OlToPurviewParsingService-GetPurviewFromOlEvent", $"Error: Spark 2 notebook name lookup failed - {ex.Message}");
                }

            }
            // Consolodate needed data from START and COMPLETE Ol events
            var messageConsolodation = new OlMessageConsolodation(olEvent, _config, _log);
            (var rslt, olEvent) = await messageConsolodation.ConsolodateEvents();
            // Returns false if this is a START event, will persist the run id and envrironment for later consolodation
            if (!rslt)
            {
                return "consolodation event";
            }
            var sparkAppParser = new SparkAppParser(_log);
            var sparkApp = sparkAppParser.GetSparkApplication(olEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties);
            var sparkProcessParser = new SparkProcessParser(_parserConfig, 
                                                            sparkApp.Attributes.QualifiedName,
                                                            sparkApp.Guid,
                                                            olEvent,
                                                            _log);
            var sparkProcess = sparkProcessParser.GetSparkProcess();

            var sparkAppStr = JsonConvert.SerializeObject(sparkApp);
            var sparkProcessStr = JsonConvert.SerializeObject(sparkProcess);

            // May want to change to creating a full model for this wrapper.
            // Because it is an array of disparate types
            // that will involve a custom json parser so leaving as a ToDo.
            return $"{PREFIX}{sparkAppStr},{sparkProcessStr}{SUFFIX}";
        }
        private Event GetEntityFromString(string olEventStr)
        {
            try
            {
                var trimString = olEventStr.Substring(olEventStr.IndexOf('{')).Trim();
                Event dEvent = JsonConvert.DeserializeObject<Event>(trimString)!;
                return dEvent;
            }
            // Parsing error
            catch
            {
                _log.LogWarning($"Unrecognized Message: {olEventStr}");
            }
            return new Event();
        }
    }
}