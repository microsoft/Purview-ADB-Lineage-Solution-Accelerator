using System.Threading.Tasks;

namespace Function.Domain.Services
{
    public interface IOlToPurviewParsingService
    {
        public Task<string> GetPurviewFromOlEvent(string olEventStr);
    }
}