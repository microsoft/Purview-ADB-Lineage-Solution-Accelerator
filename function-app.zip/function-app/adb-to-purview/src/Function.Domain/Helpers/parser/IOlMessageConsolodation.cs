using System.Threading.Tasks;
using Function.Domain.Models.OL;

namespace Function.Domain.Helpers
{
    public interface IOlMessageConsolodation
    {

        public Task<(bool, Event)> ConsolodateEvents();
        
    }
}