using Function.Domain.Models;
using Function.Domain.Models.OL;
using Function.Domain.Models.Purview;
using Function.Domain.Constants;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Function.Domain.Helpers
{
    public class QnParser: IQnParser
    {

        private List<MountPoint> _mountsInfo;
        private ParserSettings _configuration;
        private ILogger _log;

        public QnParser(List<MountPoint> mountsInfo, ParserSettings configuration, ILogger log)
        {
            _log = log;
            _mountsInfo = mountsInfo;
            _configuration = configuration;
        }           

        public PurviewIdentifier GetIdentifiers(string nameSpace, string name)
        {
            var purviewIdentifier = new PurviewIdentifier();

            // If this is an ADB mountpoint, resolve and continue
            if ((nameSpace == ParserConstants.DBFS || nameSpace ==  ParserConstants.DBFS2) && name.Substring(0,4) == "/mnt")
            {
                (string nmSpace, string nm) = GetMountPoint(name);
                nameSpace = nmSpace;
                name = nm;
            }

            // Divide connection string from prefix
            (string olPrefix, string olConnection) = GetPrefixConn(nameSpace);

            // Source is Azure SQL or Azure Synapse
            if (olPrefix == ParserConstants.SQL_SERVER)
            {
                if (!GetSqlIdentifier(olConnection, name, ref purviewIdentifier))
                {
                    _log.LogError($"Unable to parse SQL Info - Connection: {olConnection}, Name: {name}");
                }
            }

            // Source is something else
            else
            {
                // Handle ABFS being used with a blob storage URL - replace 'blob' in url with 'dfs'
                // Substring is included to handle ABFSS
                if (olPrefix.Substring(0,4) == ParserConstants.ABFS)
                {
                    olConnection = ReplaceBlob(olConnection);
                }
                
                if (!GetOtherIdentifier(olPrefix, olConnection, name, ref purviewIdentifier))
                {
                    _log.LogError($"Unable to parse ADLS or Blob source Info - Prefix: {olPrefix} Connection: {olConnection}, Name: {name}");
                    
                    // Add code to send unknown identifier if not supported Purview type
                    purviewIdentifier.Prefix = $"unknown-{olPrefix}";
                    purviewIdentifier.Connection = olConnection;
                    purviewIdentifier.Path = name.Trim('/');
                }
            }
            
            return purviewIdentifier;
        }

        private (string,string) GetMountPoint(string name)
        {
            // because it is unknown what part of the string is the mountpoint
            // and what part is the path following the mountpoint, we have to try to get the mount point
            // for each token
            string[] potentialMounts = name.Split('/');
            string potentialMountPoint = "";
            string path = "";
            MountPoint? mountPoint;
            string mountPointSource = "";
            bool gotMountPoint = false;
            foreach (var dir in potentialMounts)
            {
                if (dir != "")
                {
                    if (!gotMountPoint)
                    {
                        potentialMountPoint += $"/{dir}";
                        if ( (mountPoint = _mountsInfo.Where(m => m.MountPointName.Trim('/') == potentialMountPoint.Trim('/')).SingleOrDefault()) != null)
                        {
                            mountPointSource = mountPoint.Source;
                            gotMountPoint = true;
                        }
                    }
                    else
                    {
                        path+= $"/{dir}";
                    }
                }
            }
            return (mountPointSource.Trim('/'), path);
        }

        // Returns the prefix and connection strings
        private (string, string) GetPrefixConn(string olCon)
        {
            string olPrefix = "", olConnection = "";

            int colon = olCon.IndexOf("://");
            if (colon !=-1)
            {
                olPrefix = olCon.Substring(0,colon);
                olConnection = olCon.Substring(colon+3);
            }
            else
            {
                olPrefix = olCon;
            }
            return (olPrefix, olConnection);
        }

        private bool GetSqlIdentifier(string conn, string path, ref PurviewIdentifier purid)
        {
            path = path.Trim('/');
            conn = conn.Trim('/');
            var indexOfPeriod = conn.IndexOf('.')+1;
            var lastIndexOfColon = conn.LastIndexOf(':');
            
            // handle cases where string does not contain port number
            if (lastIndexOfColon == -1)
            {
                lastIndexOfColon = conn.IndexOf(';',indexOfPeriod);
            }
            
            string sqlType = conn.Substring(indexOfPeriod, lastIndexOfColon-indexOfPeriod);
            
            // parse database name
            var indexOfDatabase = conn.IndexOf("base=");
            // if databaseName is used instead, look for that
            if (indexOfDatabase == -1)
            {
                indexOfDatabase = conn.IndexOf("Name=");
            }
            
            indexOfDatabase += 5;
            string sqlDb = conn.Substring(indexOfDatabase, conn.IndexOf(';',indexOfDatabase)-indexOfDatabase);
            
            // parse server name
            string sqlSrv = conn.Substring(0, conn.IndexOf('.'));
            
            foreach (var map in _configuration.OlToPurviewMappings)
            {
                if (map.UrlSuffix == sqlType)
                {
                    purid.Prefix = map.PurviewPrefix;
                    purid.PurviewType = map.PurviewDatatype;
                    purid.Connection = $"{sqlSrv}.{sqlType}";
                    // <TO DO> Need to discover the schema and differentiate from the path if not dbo
                    purid.Path = $"{sqlDb}{GetSqlPath(path)}";
                    return true;
                }
            }
            
            // Did not find identifier
            return false;
        }

        private string GetSqlPath(string sqlPath)
        {
            string rtrn = "";
            
            // If path is bracketed, split into optional schema name / table
            if (sqlPath.IndexOf('[') != -1)
            {
                var rslta = sqlPath.Split('[', ']').Where(str=> str != "" && str !=".").ToArray<string>();
                // bracketed table name with schema syntax
                if (rslta.Length > 1)
                {
                    rtrn = $"/{rslta[0]}/{rslta[1]}";
                }
                // bracketed table name with default schema syntax (non dbo defaults not supported)
                else if (rslta.Length == 1)
                {
                    rtrn = $"/dbo/{rslta[0]}";
                }
            }
            
            // Explicit schema with table name syntax
            else if (sqlPath.IndexOf('.') != -1)
            {
                var rsltb = sqlPath.Split('.');
                if (rsltb.Length > 1)
                {
                    rtrn = $"/{rsltb[0]}/{rsltb[1]}";
                }
            }
            
            // Default schema with table name syntax (table name cannot include periods)
            else
            {
                rtrn = $"/dbo/{sqlPath}";
            }
            return rtrn;
        }

        private bool GetOtherIdentifier(string prefix, string conn, string path, ref PurviewIdentifier purid)
        {
            path = path.Trim('/');
            conn = conn.Trim('/');
            int at = conn.IndexOf('@');
            
            if (at != -1)
            {
                var folder = conn.Substring(0,at);
                path = (path == "") ? $"{folder}" : $"{folder}/{path}";
                //path = $"{folder}/{path}";
                conn = conn.Substring(at+1);
            }
            
            foreach (var map in _configuration.OlToPurviewMappings)
            {
                if (map.OlPrefix == prefix)
                {
                    purid.Prefix = map.PurviewPrefix;
                    purid.PurviewType = map.PurviewDatatype;
                    purid.Connection = conn;
                    purid.Path = path;
                    return true;
                }
            }
            
            return false;
        }

        private string ReplaceBlob(string potentialBlob)
        {
            if (potentialBlob.IndexOf("blob") == -1)
            { return potentialBlob; }
            
            return potentialBlob.Replace("blob", "dfs");
        }
    }

}