using System;
using System.Linq;
using System.Collections.Generic;
using Function.Domain.Models.OL;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace Function.Domain.Helpers
{
    public class FilterOlEvent
    {
        private ILogger _log;
        private Event _event = new Event();
        public FilterOlEvent(ILogger log, string strEvent)
        {
            this._log = log;

            try{
                var trimString = TrimPrefix(strEvent);
                this._event = JsonConvert.DeserializeObject<Event>(trimString) ?? new Event();
            }
            catch (JsonSerializationException ex) {
                _log.LogWarning($"Unrecognized Message: {strEvent}, error: {ex.Message} path: {ex.Path}");
            }
            // Parsing error
            catch (Exception ex){
                _log.LogWarning($"Unrecognized Message: {strEvent}, error: {ex.Message}");
            }
        }

        public bool Filter(){
            if (this._event.Inputs.Count > 0 && this._event.Outputs.Count > 0)
            {
                // Need to rework for multiple inputs and outputs in one packet - possibly combine and then hash
                if (InOutEqual(this._event))
                { return false; }
                else
                { return true; }
            }
            else
            {
                return false;
            }
        }

        public string GetJobNamespace()
        {
            return this._event.Job.Namespace;
        }

        private string TrimPrefix(string strEvent)
        {
            return strEvent.Substring(strEvent.IndexOf('{')).Trim();
        }

        private bool InOutEqual(Event ev)
        {
            List<string> nms = ev.Inputs.Select(m => m.Name.TrimEnd('/').ToLower()).ToList();
            List<string> nms2 = ev.Outputs.Select(m => m.Name.TrimEnd('/').ToLower()).ToList();
            List<string> nmspc = ev.Inputs.Select(m => m.NameSpace.TrimEnd('/').ToLower()).ToList();
            List<string> nmspc2 = ev.Outputs.Select(m => m.NameSpace.TrimEnd('/').ToLower()).ToList();
            nms.Sort();
            nms2.Sort();
            nmspc.Sort();
            nmspc2.Sort();
            return Enumerable.SequenceEqual(nms, nms2) && Enumerable.SequenceEqual(nms, nms2);
        }
    }
}