using System.Threading.Tasks;
using Function.Domain.Models.OL;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Azure;
using Azure.Data.Tables;
using Newtonsoft.Json;

namespace Function.Domain.Helpers
{
    public class OlMessageConsolodation : IOlMessageConsolodation
    {
        private IConfiguration _config;
        private ILogger _log;
        private Event _olEvent;
        private TableServiceClient _serviceClient;
        private TableClient _tableClient;


        const string STORAGE = "AzureWebJobsStorage";
        const string TABLE = "OlEventConsolodation";

        const string TABLE_PARTITION = "OlEvent_Part";
        const string TABLE_RUN_CLMN = "RunId";
        const string TABLE_ENV_CLMN = "EnvFacet";
        const string COMPLETE_EVENT = "COMPLETE";
        const string START_EVENT = "START";
        private string _storageConStr;

        public OlMessageConsolodation(Event olEvent, IConfiguration config, ILogger log)
        {
            _config = config;
            _log = log;
            _olEvent = olEvent;
            _storageConStr = _config[STORAGE];
            _serviceClient = new TableServiceClient(_storageConStr);
            _tableClient = _serviceClient.GetTableClient(TABLE);
        }

        private async Task<bool> InitTable()
        {
            try
            {
                await _serviceClient.CreateTableIfNotExistsAsync(TABLE);
            }
            catch (System.Exception ex)
            {
                _log.LogError($"OlMessageConsolodation-ProcessStartEvent: Error {ex.Message} initializing table storage");
                return false;
            }
            return true;
        }

        public async Task<(bool, Event)> ConsolodateEvents()
        {
            if (!(await InitTable()))
            {
                return(false, new Event());
            }
            // if this is a start event with an environment, store environment for 
            // future consolodation and don't return an ol event
            if (await ProcessStartEvent())
            {
                return (false, new Event());
            }
            else if (await JoinEventData())
            {
                return (true, _olEvent);
            }
            else {
                // Return origional event here. If using the old jar, the env facet would be included.
                return (false, _olEvent);
            }   
        }

        // Uses function storage account to store ol event info which must be
        // combined with other ol event data to make a complete Purview entity
        // returns true if it is a consolodation event
        private async Task<bool> ProcessStartEvent()
        {
            if (!IsStartEventEnvironment())
            {
                return false;
            }
            try
            {
                var entity = new TableEntity(TABLE_PARTITION, _olEvent.Run.RunId)
                {
                    { "EnvFacet", JsonConvert.SerializeObject(_olEvent.Run.Facets.EnvironmentProperties) }
                };

                await _tableClient.AddEntityAsync(entity);
            }
            catch (RequestFailedException)
            {
                _log.LogInformation("OlMessageConsolodation-ProcessStartEvent: Info entity already exists in table");
            }
            catch (System.Exception ex)
            {
                _log.LogError($"OlMessageConsolodation-ProcessStartEvent: Error {ex.Message} when processing entity");
                return false;
            }
            return true;
        }

        private async Task<bool> JoinEventData()
        {
            if (!IsJoinEvent())
            {
                return false;
            }

            // Lookup Run ID in table and retrieve Environment
            //Pageable<TableEntity> te = _tableClient.Query<TableEntity>(filter: TableClient.CreateQueryFilter($"PartitionKey eq {TABLE_PARTITION} and RowKey eq '{_olEvent.Run.RunId}'"));
            
            TableEntity te;
            try
            {
                te = await _tableClient.GetEntityAsync<TableEntity>(TABLE_PARTITION, _olEvent.Run.RunId, new string[] {"EnvFacet"});
            }
            catch(RequestFailedException)
            {
                // Support old jar by returning true of complete event is not in table
                return true;
            }
            
            // Add Environment to event
            var envFacet = JsonConvert.DeserializeObject<EnvironmentPropsParent>(te["EnvFacet"].ToString() ?? "");
            if (envFacet is null)
            {
                _log.LogWarning($"OlMessageConsolodation-JoinEventData: Warning environment facet for COMPLETE event is null");
                return false;
            }
            _olEvent.Run.Facets.EnvironmentProperties = envFacet;

            return true;
        }

        // Returns true if olEvent is of type START and has the environment facet
        private bool IsStartEventEnvironment()
        {
            if (_olEvent.EventType == START_EVENT && 
                _olEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties.SparkDatabricksClusterUsageTagsClusterName != "")
                {
                    return true;
                }

            return false;
        }

        private bool IsJoinEvent()
        {
            if (_olEvent.EventType == COMPLETE_EVENT)
            {
                if (_olEvent.Inputs.Count > 0 && _olEvent.Outputs.Count > 0)
                {
                    return true;
                }
                else
                {
                    _log.LogError("OlMessageConsolodation-IsJoinEvent: No Inputs and or Ouputs detected");
                    return false;
                }
            }
            else
                {
                    _log.LogWarning($"OlMessageConsolodation-IsJoinEvent: Event type is not \"{COMPLETE_EVENT}\"");
                    return false;
                }
        }
        
    }
}