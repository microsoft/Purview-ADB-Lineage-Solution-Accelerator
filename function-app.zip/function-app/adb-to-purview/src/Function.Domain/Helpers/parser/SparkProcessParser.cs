using Function.Domain.Models;
using Function.Domain.Models.OL;
using Function.Domain.Models.Purview;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Function.Domain.Helpers
{
    public class SparkProcessParser: ISparkProcessParser
    {
        private ILogger _log;
        private string _sparkAppGuid;
        private string _sparkAppQualifiedName;
        private ParserSettings _configuration;
        private IQnParser _qnParser;
        private Event _sparkEvent;

        public SparkProcessParser(ParserSettings configuration,string sparkAppQualifiedName, string sparkAppGuid, Event SparkEvent, ILogger log)
        {
            this._configuration = configuration;
            this._sparkAppQualifiedName = sparkAppQualifiedName;
            this._sparkAppGuid = sparkAppGuid;
            this._log = log;
            this._sparkEvent = SparkEvent;
            _qnParser = new QnParser(_sparkEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties.MountPoints,
                                             _configuration, _log);
        }
        public SparkProcess GetSparkProcess()
        {
            var sparkProcess = new SparkProcess();

            var inputs = new List<InputOutput>();
            foreach (IInputsOutputs input in _sparkEvent.Inputs)
            {
                inputs.Add(GetInputOutputs(input));
            }

            var outputs = new List<InputOutput>();
            foreach (IInputsOutputs output in _sparkEvent.Outputs)
            {
                outputs.Add(GetInputOutputs(output));
            }
            sparkProcess.Attributes = GetProcAttributes(inputs,outputs,_sparkEvent);

            sparkProcess.RelationshipAttributes.Application.QualifiedName = _sparkAppQualifiedName;
            sparkProcess.RelationshipAttributes.Application.Guid = _sparkAppGuid;  

            return sparkProcess;
        }

        private ProcAttributes GetProcAttributes(List<InputOutput> inputs, List<InputOutput> outputs, Event sparkEvent)
        {
            var pa = new ProcAttributes();
            pa.Name = sparkEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties.SparkDatabricksNotebookPath + sparkEvent.Outputs[0].Name;
            pa.QualifiedName = $"sparkprocess://{inputs[0].UniqueAttributes.QualifiedName.Trim('/').ToLower()}:{outputs[0].UniqueAttributes.QualifiedName.Trim('/').ToLower()}";
            pa.CurrUser = sparkEvent.Run.Facets.EnvironmentProperties.EnvironmentProperties.User;
            pa.SparkPlanDescription = sparkEvent.Run.Facets.SparkLogicalPlan.ToString(Formatting.None)!;
            pa.Inputs = inputs;
            pa.Outputs = outputs;

            return pa;
        }

        private InputOutput GetInputOutputs(IInputsOutputs inOut)
        {
            var id = _qnParser.GetIdentifiers(inOut.NameSpace,inOut.Name);
            var inputOutputId = new InputOutput();
            inputOutputId.TypeName = id.PurviewType;
            inputOutputId.UniqueAttributes.QualifiedName = id.QualifiedName;

            return inputOutputId;
        }
    }
}