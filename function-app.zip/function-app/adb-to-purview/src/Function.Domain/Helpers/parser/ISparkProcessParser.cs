using Function.Domain.Models.Purview;

namespace Function.Domain.Helpers
{
    public interface ISparkProcessParser
    {
        public SparkProcess GetSparkProcess();
    }
}