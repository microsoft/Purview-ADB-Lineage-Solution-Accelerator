using Function.Domain.Models.Purview;
using Function.Domain.Models.OL;
using Microsoft.Extensions.Logging;

namespace Function.Domain.Helpers
{
    public class SparkAppParser: ISparkAppParser
    {
        private const string APP_NOTEBOOK = "notebook";
        private const string APP_SHELL = "shell";
        private const string APP_JAR = "jar";
        private const string APP_EGG = "egg";

        private ILogger _log;
        public SparkAppParser(ILogger log)
        {
            this._log = log;
        }

        public SparkApplication GetSparkApplication(EnvironmentProps envProps)
        {
            var sparkApp = new SparkApplication();
            string notebookPath = envProps.SparkDatabricksNotebookPath.Trim('/').ToLower();
            if (notebookPath != null)
            {
                // This is a notebook based application
                sparkApp.Attributes.Name = notebookPath.Substring(notebookPath.LastIndexOf('/')+1);
                sparkApp.Attributes.AppType = APP_NOTEBOOK;
                sparkApp.Attributes.QualifiedName = $"{APP_NOTEBOOK}://{notebookPath}";
            }
            return sparkApp;
        }
    }
}