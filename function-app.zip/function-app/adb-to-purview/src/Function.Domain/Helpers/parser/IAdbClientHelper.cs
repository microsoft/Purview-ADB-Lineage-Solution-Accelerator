using System.Threading.Tasks;

namespace Function.Domain.Helpers
{
    public interface IAdbClientHelper
    {
        public Task<string> GetSingleAdbJobAsync(string correlationId, long runId, string adbWorkspaceUrl);
    }
}