using System;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using Newtonsoft.Json.Linq;
using Microsoft.Extensions.Logging;

namespace Function.Domain.Helpers
{
    class AdbClientHelper : IAdbClientHelper
        {
        private string _tenantId;
        private string _clientId;
        private string _clientSecret;

        // static for simple function cache
        private static JwtSecurityToken? _managementToken;
        private static JwtSecurityToken? _bearerToken;
        private string _notebookTask = "";
        private HttpClient _client;
        private ILogger _log;

        public AdbClientHelper(IConfiguration config, ILogger log)
        {
            _log = log;
            _client  = new HttpClient();
            _tenantId = config["TenantId"];
            _clientId = config["ClientId"];
            _clientSecret = config["ClientSecret"];
        }
        private async Task GetBearerTokenAsync(string correlationId)
        {
            try {
                var BaseAddress = $"https://login.microsoftonline.com/{_tenantId}/oauth2/v2.0/token";
                var form = new Dictionary<string, string>
                {
                    {"grant_type", "client_credentials"},
                    {"scope", "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d/.default"},
                    {"client_id", _clientId },
                    {"client_secret", _clientSecret}
                };

                var tokenResponse = await _client.PostAsync(BaseAddress, new FormUrlEncodedContent(form));

                tokenResponse.EnsureSuccessStatusCode();
                JObject? resultjson = JObject.Parse(tokenResponse.Content.ReadAsStringAsync().Result);
                if (resultjson is not null)
                {
                    _bearerToken = new JwtSecurityToken((resultjson.SelectToken("access_token") ?? "").ToString());
                }
            }
            catch (Exception ex) 
            {
                _log.LogError(correlationId, $"AdbClient-GetBearerTokenAsync: error, message: {ex.Message}");
            }
        }
        private async Task GetManagementTokenAsync(string correlationId)
        {
            try {
                var BaseAddress = $"https://login.microsoftonline.com/{_tenantId}/oauth2/token";
                var form = new Dictionary<string, string>
                {
                    {"Authorization: Bearer", _bearerToken!.RawData},
                    {"grant_type", "client_credentials"},
                    {"resource", "https://management.core.windows.net/"},
                    {"client_id", _clientId },
                    {"client_secret", _clientSecret}
                };

                var tokenResponse = await _client.PostAsync(BaseAddress, new FormUrlEncodedContent(form));

                tokenResponse.EnsureSuccessStatusCode();
                JObject? resultjson = JObject.Parse(tokenResponse.Content.ReadAsStringAsync().Result);
                _managementToken = new JwtSecurityToken((resultjson.SelectToken("access_token") ?? "").ToString());
            }
            catch (Exception ex)
            {
                _log.LogError(correlationId, $"AdbClient-GetManagementTokenAsync: error, message: {ex.Message}");
            }
        }
        public async Task<string> GetSingleAdbJobAsync(string correlationId, long runId, string adbWorkspaceUrl)
        {
            if (isTokenExpired(_bearerToken))
            {
                await GetBearerTokenAsync(correlationId);
                if (_bearerToken is null) return "";
            }

            if (isTokenExpired(_managementToken))
            {
                await GetManagementTokenAsync(correlationId);
                if (_managementToken is null) return "";
            }

            var request = new HttpRequestMessage() {
                RequestUri = new Uri($"https://{adbWorkspaceUrl}.azuredatabricks.net/api/2.1/jobs/runs/get?run_id={runId}"),
                Method = HttpMethod.Get,
            };
            request.Headers.Authorization  =
                new AuthenticationHeaderValue("Bearer", _bearerToken!.RawData);
            request.Headers.TryAddWithoutValidation("X-Databricks-Azure-SP-Management-Token", _managementToken!.RawData);

           try {
                var tokenResponse = await _client.SendAsync(request);

                tokenResponse.EnsureSuccessStatusCode();
                var resultjson = JObject.Parse(tokenResponse.Content.ReadAsStringAsync().Result);
                _notebookTask = ((((resultjson["tasks"] ?? "" )[0] ?? "" )["notebook_task"] ?? "" )["notebook_path"] ?? "").ToString();
            }
            catch (Exception ex)
            {
                _log.LogError(correlationId, $"AdbClient-GetSingleAdbJobAsync: error, message: {ex.Message}");
            }
            return _notebookTask;
        }
        private bool isTokenExpired(JwtSecurityToken? jwt)
        {
            if (jwt is null)
            {
                return true;
            }
            if (jwt.ValidTo > DateTime.Now.AddMinutes(3))
            {
                _log.LogInformation("AdbClient-isTokenExpired: Token cache hit");
                return false;
            }
            return true;
        }
    }
}