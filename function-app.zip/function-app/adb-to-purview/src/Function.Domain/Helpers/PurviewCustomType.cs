﻿using Newtonsoft.Json.Linq;
using System;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Function.Domain.Providers;
using Function.Domain.Models;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using Function.Domain.Models.Purview;
using System.Collections.Generic;


namespace Function.Domain.Helpers
{

    public class PurviewCustomType
    {
        private readonly ILogger _logger;
        private readonly string EntityType = "purview_custom_connector_generic_entity_with_columns";
        private PurviewClient _client;
        private JObject? simpleEntity;
        private JObject? properties;

        public JObject? Fullentity = new JObject();
        bool useResourceSet = bool.Parse(Environment.GetEnvironmentVariable("useResourceSet") ?? "true");
        bool usePurviewTypes = bool.Parse(Environment.GetEnvironmentVariable("usePurviewTypes") ?? "false");

        public JObject Properties
        {
            get { return properties!; }
        }

        public PurviewCustomType(string name, string typeName, string qualified_name, string data_type, string description, Int64 guid, ILogger logger, PurviewClient client)
        {
            _logger = logger;
            _client = client;
            Init(name
            , typeName
            , qualified_name
            , data_type
            , description
            , guid
            );
            _logger.LogInformation($"New Entity Initialized in the process with a passed Purview Client: Nome:{name} - qualified_name:{qualified_name} - Guid:{guid}");
        }
        public PurviewCustomType(string name, string typeName, string qualified_name, string data_type, string description, Int64 guid, ILogger logger)
        {
            _logger = logger;
            _client = new PurviewClient(_logger!);
            Init(name
            , typeName
            , qualified_name
            , data_type
            , description
            , guid
            );
            _logger.LogInformation($"New Entity Initialized in the process with internal Purview Client: Nome:{name} - qualified_name:{qualified_name} - Guid:{guid}");
        }
        private void Init(string name, string typeName, string qualified_name, string data_type, string description, Int64 guid)
        {
            is_dummy_asset = false;
            properties = new JObject();
            simpleEntity = new JObject();
            //Loading Entity properties into Json format of an AtlasEntity
            properties.Add("typeName", typeName);
            properties.Add("guid", guid);
            properties.Add("attributes", new JObject());
            properties.Add("relationshipAttributes", new JObject());
            ((JObject)properties["attributes"]!).Add("name", name);
            ((JObject)properties["attributes"]!).Add("qualifiedName", qualified_name);
            ((JObject)properties["attributes"]!).Add("data_type", data_type);
            ((JObject)properties["attributes"]!).Add("description", description);
        }
        public JObject SimpleEntity
        {
            get
            {
                //Simple Json format for use in Atlas requests
                simpleEntity = new JObject();
                simpleEntity.Add("typeName", this.Properties["typeName"]!.ToString());
                simpleEntity.Add("guid", this.Properties["guid"]!.ToString());
                simpleEntity.Add("qualifiedName", this.Properties["attributes"]!["qualifiedName"]!.ToString());
                _logger.LogInformation($"Retrived Entity simple Object: {simpleEntity.ToString()}");
                return simpleEntity;
            }
        }
        public async Task<List<Asset>> GetEntity()
        {
            var entities = await _client.Get_Entity(properties!["attributes"]!["qualifiedName"]!.ToString()
                , properties!["typeName"]!.ToString());

            return entities;
        }

        public bool is_dummy_asset { get; set; }

        public bool AddToTable(PurviewCustomType Table)
        {
            //Validating if the table attribute exists if not we will initialize
            if (!((JObject)properties!["relationshipAttributes"]!).ContainsKey("table"))
                ((JObject)properties!["relationshipAttributes"]!).Add("table", new JObject());

            _logger.LogInformation($"Entity qualifiedName: {properties["attributes"]!["qualifiedName"]}Table.simpleEntity: {Table!.simpleEntity!.ToString()}");
            properties["relationshipAttributes"]!["table"] = Table.simpleEntity;
            return true;
        }

        public async Task<JObject> FindQualifiedNameInPurview(string typeName)
        {
            //Search using search method and qualifiedname attribute. Scape needs to be used on some non safe (web URLs) chars
            EntityModel results = await this._client.search_entities(
                properties!["attributes"]!["qualifiedName"]!.ToString()
                , typeName);

            if (results.qualifiedName == null)
            {
                _logger.LogInformation($"Entity qualifiedName:{properties["attributes"]!["qualifiedName"]!.ToString()} - typeName:{typeName}, not found!");
                this.is_dummy_asset = true;
                properties["typeName"] = EntityType;
                return new JObject();
            }
            var guid = "";
            this.is_dummy_asset = false;
            var _qualifiedName = "";
            //validate if qualifiedname is the same
            _qualifiedName = results.qualifiedName;
            if (results.entityType == "azure_datalake_gen2_resource_set")
                properties["attributes"]!["qualifiedName"] = _qualifiedName;
            if (_qualifiedName.Trim('/').ToLower() == properties["attributes"]!["qualifiedName"]!.ToString().Trim('/').ToLower())
            {
                //search api return quid on ID property
                guid = results.id;
                properties["typeName"] = results.entityType;
                properties!["attributes"]!["qualifiedName"] = results.qualifiedName;
                //break if find a non dummy entity with the qualified name
                if (results.entityType == EntityType)
                {
                    //log.debug("search_entity_by_qualifiedName: entity \'{name}\' is Dummy Entity");
                    //mark entity as dummy to be created
                    this.is_dummy_asset = true;
                }
                _logger.LogInformation($"Entity qualifiedName:{properties["attributes"]!["qualifiedName"]!.ToString()} - typeName:{typeName} - guid:{guid}, found!");
            }

            if (!this.is_dummy_asset)
                properties!["attributes"]!["qualifiedName"] = results.qualifiedName;

            var content = new JObject();
            content.Add(_qualifiedName, new JObject());
            properties["guid"] = guid;
            ((JObject)content[_qualifiedName]!).Add("guid", guid);
            ((JObject)content[_qualifiedName]!).Add("qualifiedName", properties!["attributes"]!["qualifiedName"]!.ToString());

            return content;
        }
        public async Task<bool> CleanUnusedCustomEntities()
        {
            return await this._client.Delete_Unused_Entity(
                properties!["attributes"]!["qualifiedName"]!.ToString()
                , properties!["typeName"]!.ToString());
        }

        private List<string>? qNames = new List<string>();
        public async Task<QueryValeuModel> QueryInPurview()
        {
            return await QueryInPurview(string.Empty);
        }
        public async Task<QueryValeuModel> QueryInPurview(string TypeName)
        {
            QueryValeuModel obj = new QueryValeuModel();
            //string[] names = this.properties!["attributes"]!["qualifiedName"]!.ToString().Split('/');
            qNames = Build_Searchable_QualifiedName(this.properties!["attributes"]!["qualifiedName"]!.ToString());
            JObject filter = new JObject();
            this.is_dummy_asset = true;

            foreach (string name in qNames!)
            {
                //                if (this.Is_Valid_Name(name))
                //                {
                //qNames.Add(name);
                if (!filter.ContainsKey("filter"))
                {
                    filter.Add("filter", new JObject());
                    ((JObject)filter!["filter"]!).Add("and", new JArray());
                }
                //SUpport for the cases when user use wasbs protocall for a ADLS GEN 2
                if ((name.Contains(".dfs.core.windows.net")) || (name.Contains(".blob.core.windows.net")))
                {
                    string orName = name.Contains(".dfs.core.windows.net") ? name.Replace(".dfs.core.windows.net", ".blob.core.windows.net") : name.Replace(".blob.core.windows.net", ".dfs.core.windows.net");
                    var orcondition = new JObject();
                    orcondition.Add("or", new JArray());
                    var condition = new JObject();
                    condition.Add("attributeName", "qualifiedName");
                    condition.Add("operator", "contains");
                    condition.Add("attributeValue", name);
                    ((JArray)((JObject)orcondition!)["or"]!).Add(condition);
                    condition = new JObject();
                    condition.Add("attributeName", "qualifiedName");
                    condition.Add("operator", "contains");
                    condition.Add("attributeValue", orName);
                    ((JArray)((JObject)orcondition!)["or"]!).Add(condition);
                    ((JArray)((JObject)filter!["filter"]!)["and"]!).Add(orcondition);
                }
                else
                {
                    var condition = new JObject();
                    condition.Add("attributeName", "qualifiedName");
                    condition.Add("operator", "contains");
                    condition.Add("attributeValue", name);
                    ((JArray)((JObject)filter!["filter"]!)["and"]!).Add(condition);
                }
                //                }
            }
            if (filter.ContainsKey("filter"))
            {
                if ((((JArray)((JObject)filter!["filter"]!)["and"]!).Count > 0) && (this.properties!["typeName"]!.ToString().ToLower() != "spark_process"))
                {
                    var condition = new JObject();
                    condition.Add("not", new JObject());
                    ((JObject)condition["not"]!).Add("entityType", "spark_process");
                    ((JArray)((JObject)filter!["filter"]!)["and"]!).Add(condition);
                    Console.WriteLine(filter.ToString());
                }
                if (TypeName != string.Empty)
                {
                    var condition = new JObject();
                    condition.Add("entityType", TypeName);
                    ((JArray)((JObject)filter!["filter"]!)["and"]!).Add(condition);
                }
            }

            List<QueryValeuModel> results = await this._client.Query_entities(filter["filter"]!);
            if (results.Count == 1)
            {
                if (results[0].entityType == "spark_application")
                    if (results[0].qualifiedName.ToLower().Trim('/') != this.properties!["attributes"]!["qualifiedName"]!.ToString().ToLower().Trim('/'))
                    {
                        this.is_dummy_asset = true;
                        return obj;
                    }
                properties["guid"] = results[0].id;
                properties["typeName"] = results[0].entityType;
                properties!["attributes"]!["qualifiedName"] = results[0].qualifiedName;
                this.Fullentity = await this._client.GetByGuid(results[0].id);
                this.is_dummy_asset = false;
                return results[0];
            }
            if (results.Count > 0)
            {
                List<QueryValeuModel> validentity = await SelectReturnEntity(results);
                if (validentity.Count > 0)
                {
                    obj = validentity[0];
                    properties["guid"] = validentity[0].id;
                    properties["typeName"] = validentity[0].entityType;
                    properties!["attributes"]!["qualifiedName"] = validentity[0].qualifiedName;
                    this.Fullentity = await this._client.GetByGuid(validentity[0].id);
                    this.is_dummy_asset = false;
                }
            }
            else
            {
                properties["typeName"] = EntityType;
            }
            return obj;
        }
        private async Task<List<QueryValeuModel>> SelectReturnEntity(List<QueryValeuModel> results)
        {
            List<QueryValeuModel> validEntities = new List<QueryValeuModel>();
            foreach (QueryValeuModel entity in results)
            {
                string qualifiednameToCompera = string.Join("/", this.Build_Searchable_QualifiedName(entity.qualifiedName)!);
                if ((entity.entityType == "azure_datalake_gen2_resource_set") || (entity.entityType == "azure_blob_resource_set"))
                {
                    if (qualifiednameToCompera.ToLower().Trim() == this.to_compare_QualifiedName.ToLower().Trim())
                    //if (entity.qualifiedName.ToLower().Trim().IndexOf(this.properties!["attributes"]!["qualifiedName"]!.ToString().ToLower().Trim()) > -1)
                    {
                        validEntities.Add(entity);
                    }
                }
                else
                {
                    if (qualifiednameToCompera.ToLower().Trim('/') == this.to_compare_QualifiedName.ToLower().Trim('/'))
                    //                    if (entity.qualifiedName.ToLower().Trim('/') == this.properties!["attributes"]!["qualifiedName"]!.ToString().ToLower().Trim('/'))
                    {
                        if ((entity.entityType.ToLower() == "azure_blob_path") || (entity.entityType.ToLower() == "azure_datalake_gen2_path") || (entity.entityType.ToLower() == "azure_datalake_gen2_filesystem"))
                        {
                            if (validEntities.Count > 0)
                            {
                                JObject folder = await _client.GetByGuid(entity.id);
                                if (folder.ContainsKey("entity"))
                                {
                                    if (((JArray)folder!["entity"]!["relationshipAttributes"]!["inputToProcesses"]!).Count > 0)
                                    {
                                        foreach (JObject val in ((JArray)folder!["entity"]!["relationshipAttributes"]!["inputToProcesses"]!))
                                        {
                                            if (val!["typeName"]!.ToString().ToLower().IndexOf("adf_") > -1)
                                            {
                                                validEntities = new List<QueryValeuModel>();
                                                validEntities.Add(entity);
                                                return validEntities;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (((JArray)folder!["entity"]!["relationshipAttributes"]!["outputFromProcesses"]!).Count > 0)
                                        {
                                            foreach (JObject val in ((JArray)folder!["entity"]!["relationshipAttributes"]!["outputFromProcesses"]!))
                                            {
                                                if (val!["typeName"]!.ToString().ToLower().IndexOf("adf_") > -1)
                                                {
                                                    validEntities = new List<QueryValeuModel>();
                                                    validEntities.Add(entity);
                                                    return validEntities;
                                                }
                                            }
                                        }

                                    }
                                }
                            }
                        }
                        validEntities.Add(entity);
                    }
                }
            }
            return validEntities;

        }

        private string Name_To_Search(string Name)
        {
            Func<string, bool> isNumber = delegate (string num)
             {
                 return Int64.TryParse(num, out long number)!;
             };

            Func<char, string> newName = delegate (char separator)
             {
                 string[] partsName = Name.Split(separator);
                 int index = 0;
                 foreach (string? part in partsName)
                 {
                     if (isNumber(part))
                         partsName[index] = "{N}";
                     index++;
                 }
                 return string.Join(separator,partsName)!;
             };

            if (isNumber(Name))
            {
                return "{N}";
            }

            if (Name.Contains('='))
            {
                return newName('=');
            }

            if (Name.Contains('-'))
            {
                return newName('-');
            }

            if (Name.Contains('_'))
            {
                return newName('_');
            }

            return Name;
        }
        private bool Is_Valid_Name(string name)
        {
            Func<string, bool> isNumber = delegate (string num)
             {
                 return Int64.TryParse(num, out long number)!;
             };

            if (name.Trim() == string.Empty)
                return false;
            if (name.Contains('='))
            {
                string[] partsName = name.Split("=");
                foreach (string part in partsName)
                {
                    if (isNumber(part))
                        return false;
                }
            }

            if ((this.properties!["typeName"]!.ToString().ToLower().Trim('/') == "azure_datalake_gen2_resource_set") ||
                (this.properties!["typeName"]!.ToString().ToLower().Trim('/') == "azure_datalake_gen2_path") ||
                (this.properties!["typeName"]!.ToString().ToLower().Trim('/') == "azure_blob_path") ||
                (this.properties!["typeName"]!.ToString().ToLower().Trim('/') == "azure_blob_resource_set")
              )
            {
                if (isNumber(name))
                    return false;
                if ((name.Contains('{')) && (name.Contains('}')))
                    return false;

                if ((name.ToLower().IndexOf(".csv") > -1) || (name.ToLower().IndexOf(".parquet") > -1))
                {
                    foreach (char charactere in name.ToCharArray())
                    {
                        if (isNumber(charactere.ToString()))
                            return false;
                    }
                }
            }
            return true;
        }
        private List<string>? Build_Searchable_QualifiedName(string qualifiedName)
        {
            string[] names = qualifiedName.Split('/');
            List<string> validNames = new List<string>();
            int indexCount = 0;
            foreach (string name in names)
            {
                if (indexCount > 2)
                {
                    if (this.Is_Valid_Name(name))
                    {
                        validNames.Add(name);
                    }
                }
                else
                {
                    if (indexCount != 1)
                        validNames.Add(name);
                }
                indexCount++;
            }

            return validNames;
        }
        private string to_compare_QualifiedName
        {
            get
            {
                if (this.qNames!.Count == 0)
                {
                    this.qNames.AddRange(this.properties!["attributes"]!["qualifiedName"]!.ToString().Split('/'));
                }
                return string.Join("/", this.qNames!);
            }
        }
    }

    public class PurviewClient
    {
        private Int64 initGuid = -1000;
        private readonly PurviewClientHelper PurviewclientHelper;
        private readonly IHttpClientManager httpclientManager;
        ILogger _logger;
        private AuthenticationResult? _token;
        public PurviewClient(ILogger logger)
        {
            _logger = logger;
            httpclientManager = new HttpClientManager(logger);
            this.PurviewclientHelper = new PurviewClientHelper(httpclientManager, logger);
            GetToken();
        }

        public async Task<EntityModel> search_entities(string QualifiedName, string typeName)
        {
            var correlationId = Guid.NewGuid().ToString();
            var token = this.GetToken();
            var baseurl = $"https://{Environment.GetEnvironmentVariable("PurviewAccountName") ?? ""}.catalog.purview.azure.com/api";
            var purviewSearchEndpoint = $"{baseurl}/atlas/v2/search/advanced";
            PurviewEntitySearchResponseModel entityObjectModel = new PurviewEntitySearchResponseModel();
            try
            {
                var filtervalue = new { typeName = typeName };
                if (typeName != String.Empty)
                {
                    _logger.LogTrace($"Searching entity using qualifiedName:{QualifiedName} typeName:{typeName}");
                    entityObjectModel = await this.PurviewclientHelper.GetEntitiesFromPurview(
                        correlationId
                        , QualifiedName
                        , purviewSearchEndpoint
                        , token,
                        filtervalue
                        );
                    if (entityObjectModel.entities.Count > 0)
                    {
                        _logger.LogTrace($"Found {entityObjectModel.entities.Count} Entities for qualifiedName:{QualifiedName} typeName:{typeName}");
                        var foundEntity = new Function.Domain.Models.EntityModel();
                        foreach (var entity in entityObjectModel.entities)
                        {
                            foundEntity = entity;
                            if (entity.entityType == typeName)
                            {
                                break;
                            }

                            _logger.LogTrace($"Found entity typeName:{entity.entityType}");
                        }
                        return foundEntity;
                    }
                }
                else
                {
                    _logger.LogTrace($"Searching entity using qualifiedName:{QualifiedName}");
                    entityObjectModel = await this.PurviewclientHelper.GetEntitiesFromPurview(
                        correlationId
                        , QualifiedName
                        , purviewSearchEndpoint
                        , token
                        );
                    var foundEntity = new Function.Domain.Models.EntityModel();
                    _logger.LogTrace($"Found {entityObjectModel.entities.Count} Entities for qualifiedName:{QualifiedName} typeName:{typeName}");
                    foreach (var entity in entityObjectModel.entities)
                    {
                        foundEntity = entity;
                        if (entity.entityType == "purview_custom_connector_generic_entity_with_columns")
                            break;
                        _logger.LogTrace($"Found entity typeName:{entity.entityType}");
                    }
                    return foundEntity;
                }

            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
            }

            return new EntityModel();
        }

        public async Task<bool> Delete_Unused_Entity(string quilifiedName, string typeName)
        {
            var correlationId = Guid.NewGuid().ToString();
            var token = this.GetToken();
            var baseurl = $"https://{Environment.GetEnvironmentVariable("PurviewAccountName") ?? ""}.purview.azure.com/catalog/api";
            var purviewSearchEndpoint = $"{baseurl}/atlas/v2/entity/bulk/uniqueAttribute/type/";
            var deleteEndPoint = $"{baseurl}/atlas/v2/entity/guid/";
            List<Asset> entities = await PurviewclientHelper.GetEntityFromPurview(correlationId, quilifiedName.Trim('/').ToLower(), purviewSearchEndpoint, token, typeName);

            foreach (var entity in entities)
            {
                bool isUnused = false;
                if (entity!.relationshipAttributes!.ContainsKey("outputFromProcesses"))
                    if (((JArray)entity.relationshipAttributes!["outputFromProcesses"]).Count == 0)
                        isUnused = false;
                    else
                        isUnused = true;

                if (!isUnused)
                {
                    if (entity!.relationshipAttributes!.ContainsKey("inputToProcesses"))
                        if (((JArray)entity.relationshipAttributes!["inputToProcesses"]).Count == 0)
                            isUnused = false;
                        else
                            isUnused = true;
                }

                if (!isUnused)
                    await PurviewclientHelper.DeleteEntityByGuidInPurview(correlationId, token, entity.guid, deleteEndPoint);
            }

            return true;
        }
        public async Task<EntityModel> search_entities(string QualifiedName)
        {
            return await search_entities(QualifiedName, String.Empty);
        }
        private string GetToken()
        {

            if (_token != null)
            {
                if (_token.ExpiresOn > DateTimeOffset.Now)
                {
                    _logger.LogTrace($"Token to access Purview was reused");
                    return _token.AccessToken;
                }
            }

            //The _client id that Azure AD created when you registered your _client app.
            string _clientID = Environment.GetEnvironmentVariable("ClientID") ?? "";
            string _clientSecret = Environment.GetEnvironmentVariable("ClientSecret") ?? "";

            string TenantId = Environment.GetEnvironmentVariable("TenantId") ?? "";

            string resourceUri = Environment.GetEnvironmentVariable("ResourceUri") ?? "";
            string AuthEndPoint = Environment.GetEnvironmentVariable("AuthEndPoint") ?? "";

            AuthEndPoint = $"{AuthEndPoint}{TenantId}";

            ClientCredential cc = new ClientCredential(_clientID, _clientSecret);
            var context = new AuthenticationContext(string.Format(AuthEndPoint, TenantId));
            var result = context.AcquireTokenAsync(resourceUri, cc);
            if (result == null)
            {
                _logger.LogError("Error geting Authentication Token ofr Purview API");
                return String.Empty;
            }
            if(result.Result==null)
            {
                _logger.LogError($"Error geting Authentication Token ofr Purview API: {result!.Exception!.Message}");
                return String.Empty;
            }
            _token = result.Result;
            _logger.LogInformation($"Token to access Purview was generated");
            return _token.AccessToken;
        }

        public async Task<HttpResponseMessage> Send_to_Purview(string payloadJson)
        {
            var correlationId = Guid.NewGuid().ToString();
            var token = this.GetToken();
            if (token == String.Empty)
            {
                _logger.LogError("Unable to get Token to Purview");
                return new HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
            }


            _logger.LogInformation($"Sending this payload to Purview: {payloadJson}");

            var baseurl = $"https://{Environment.GetEnvironmentVariable("PurviewAccountName") ?? ""}.catalog.purview.azure.com/api";
            var purviewEntityEndpoint = $"{baseurl}/atlas/v2/entity/bulk";

            HttpResponseMessage? response = await this.PurviewclientHelper.PostEntitiesToPurview(
                correlationId,
                token,
                JObject.Parse(payloadJson),
                purviewEntityEndpoint
            ) ?? new HttpResponseMessage(System.Net.HttpStatusCode.NoContent);
            return response;
        }

        public async Task<List<QueryValeuModel>> Query_entities(object filter)
        {
            var correlationId = Guid.NewGuid().ToString();
            var token = this.GetToken();
            var baseurl = $"https://{Environment.GetEnvironmentVariable("PurviewAccountName") ?? "purview-to-adb-demo-openlineage-purview"}.catalog.purview.azure.com/api";
            var purviewSearchEndpoint = $"{baseurl}/search/query?api-version=2021-05-01-preview";

            List<QueryValeuModel> returnValue = await PurviewclientHelper.QueryEntities(correlationId, token, purviewSearchEndpoint, filter);

            return returnValue;
        }
        public async Task<JObject> GetByGuid(string guid)
        {
            var token = this.GetToken();
            var baseurl = $"https://{Environment.GetEnvironmentVariable("PurviewAccountName") ?? "purview-to-adb-demo-openlineage-purview"}.purview.azure.com/catalog/api";
            var purviewSearchEndpoint = $"{baseurl}/atlas/v2/entity/guid/";
            JObject entity = await PurviewclientHelper.GetEntityByGuid(token, purviewSearchEndpoint, guid);
            return entity;
        }
        public async Task<List<Asset>> Get_Entity(string quilifiedName, string typeName)
        {
            var correlationId = Guid.NewGuid().ToString();
            var token = this.GetToken();
            var baseurl = $"https://{Environment.GetEnvironmentVariable("PurviewAccountName") ?? ""}.purview.azure.com/catalog/api";
            var purviewSearchEndpoint = $"{baseurl}/atlas/v2/entity/bulk/uniqueAttribute/type/";
            var deleteEndPoint = $"{baseurl}/atlas/v2/entity/guid/";
            List<Asset> entities = await PurviewclientHelper.GetEntityFromPurview(correlationId, quilifiedName.Trim('/').ToLower(), purviewSearchEndpoint, token, typeName);
            return entities;
        }

        public Int64 NewGuid()
        {

            return initGuid--;
        }
    }

}
